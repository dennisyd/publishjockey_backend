# Secure the Bag

## Money Lessons Every School Should Teach

### By **Dee Martine**

