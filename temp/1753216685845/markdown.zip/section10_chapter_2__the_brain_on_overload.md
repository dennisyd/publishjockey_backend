# Chapter 2: The Brain on Overload

Your mind is an extraordinary instrument, capable of composing symphonies, solving complex equations, and experiencing the profound depths of human emotion. Yet this same marvel of evolution—with its 86 billion neurons forming trillions of connections—can be completely derailed by a simple notification on your phone.

Why?

To truly understand how to vanquish the noise in your life, you need to first understand the brain you’re working with. Not the idealized brain that productivity gurus often assume you have, but your actual human brain—with all its magnificent capabilities and surprising vulnerabilities.

## The Attention System: Your Brain’s Mission Control

Attention is not a single capacity but a complex network of neural mechanisms working in concert. Neuroscientists typically divide attention into three primary systems:

### 1\. The Alerting Network

The alerting network is your brain’s basic vigilance system—the part that wakes you when you hear a strange sound at night or perks up when something new enters your environment. Located primarily in your brain stem and thalamus, this network receives input from your sensory systems and prepares other brain regions for incoming information.

This vigilance served our ancestors well—detecting the rustling in the grass that might be a predator was a survival advantage. But in today’s environment, this same system treats every ping, ding, and notification as potentially significant, repeatedly triggering alertness throughout your day.

Research from the University of California shows that the average knowledge worker is interrupted every six minutes. Each interruption activates this alerting network, triggering a cascade of stress hormones including cortisol and adrenaline. These hormones evolved for occasional life-threatening situations, not the hundreds of micro-stressors we now encounter daily.

### 2\. The Orienting Network

Once alerted, your orienting network directs your attentional spotlight toward relevant stimuli. This network, primarily located in your parietal and frontal lobes, allows you to select what deserves your focus among competing inputs.

The orienting network evolved to help us identify the most relevant information in our environment. The challenge? It’s biased toward novelty, movement, and emotional content—precisely what digital technologies are designed to provide.

“Our orienting response is automatically triggered by bright colors, sudden movements, and pattern changes,” explains neuroscientist Dr. Adam Gazzaley. “App designers know this and deliberately incorporate these elements to capture our attention.”

This explains why you might sit down to work on an important project but find your attention repeatedly pulled toward a flashing notification or moving image on your screen. Your orienting network is functioning exactly as designed—just in an environment it wasn’t designed for.

### 3\. The Executive Control Network

The most sophisticated attention system is your executive control network, primarily housed in your prefrontal cortex. This system allows you to:

*   Maintain focus despite distractions
*   Switch between tasks when appropriate
*   Inhibit inappropriate responses
*   Hold information in working memory

This is your brain’s CEO, making high-level decisions about where your attention should go based on your goals and values rather than merely reacting to external stimuli.

The executive control network is what allows you to focus on writing a report despite the allure of social media, or to stay engaged in a conversation even when your phone buzzes. It’s the neural basis of what we commonly call willpower or self-control.

But here’s the crucial insight: the executive control network is metabolically expensive, has limited capacity, and fatigues with use.

“The prefrontal cortex is the newest part of the brain evolutionarily and the most fragile,” notes neuropsychologist Dr. William Dodson. “It’s easily disrupted by stress, fatigue, boredom, hunger—and constant distraction.”

This biological reality lies at the heart of our modern attention crisis. When we expect our executive control network to function at peak capacity amid constant distractions, we’re setting ourselves up for failure.

## Working Memory: The Brain’s Limited Workspace

At the center of your cognitive operations is working memory—your brain’s temporary holding space for information currently in use. Working memory is what allows you to hold a phone number in mind while dialing, follow the thread of a conversation, or keep track of where you are in a complex task.

The crucial limitation? Working memory has dramatically finite capacity.

Cognitive psychologist George Miller famously proposed that most people can hold only about seven items (plus or minus two) in working memory at once. More recent research suggests the capacity may be even smaller—closer to four items for most complex information.

This limitation becomes critical when we consider task-switching. Each time you shift attention—from your work to an email notification and back again—you’re not simply picking up where you left off. Instead, you’re reloading your working memory, a process that creates what productivity researcher Gloria Mark calls “attention residue.”

“When people switch contexts, they don’t completely clear their working memory,” explains Mark. “Some of the prior task remains, contaminating their attention to the new task.”

This helps explain why studies show it takes an average of 23 minutes to fully refocus after an interruption. Your brain isn’t just toggling between tasks; it’s doing the cognitive equivalent of closing multiple programs and reopening them—a process that consumes time and mental energy.

The limited capacity of working memory also explains why multitasking is largely an illusion. When you believe you’re doing two cognitive tasks simultaneously, you’re actually rapidly switching between them, with each switch incurring a cognitive cost. This switching creates a “bottleneck” effect in the brain, slowing down performance on both tasks and increasing error rates.

Stanford researchers found that heavy multitaskers performed worse on tests of memory, attention filtering, and task switching compared to those who typically focused on one task at a time. The most surprising finding? The multitaskers weren’t even aware of their impaired performance.

## The Novelty Bias: Your Brain’s Attraction to the New

Your brain contains specialized circuitry that privileges new information over familiar information—what neuroscientists call the “novelty bias.” This preference for novelty is mediated by dopamine, a neurotransmitter involved in motivation, pleasure, and learning.

When you encounter something new, your brain releases dopamine, creating a sense of pleasure and interest. This mechanism evolved for good reason—exploring novel aspects of our environment helped our ancestors discover new food sources, identify potential threats, and adapt to changing conditions.

But in today’s information environment, your novelty bias can work against you. As neuroscientist Dr. Wolfram Schultz explains, “Dopamine responds to unpredictable reward more strongly than to predictable reward.”

This is precisely why checking email, refreshing social media feeds, or browsing news sites can become compulsive behaviors. These platforms deliver unpredictable, variable rewards—sometimes you’ll find something interesting or validating, sometimes not. This intermittent reinforcement schedule is the same mechanism that makes gambling so addictive.

Technology companies understand and exploit this neurological vulnerability. Tristan Harris, former design ethicist at Google, describes how product designers create “slot machine” effects in their apps:

“When you pull to refresh your Facebook feed, you’re playing a slot machine to see what new stuff shows up. When you swipe down your Twitter feed, you’re playing a slot machine to see what’s new. And those design decisions are not neutral. They’re designing to optimize for your attention.”

The dopamine release triggered by novel information creates a reward circuit that can override your conscious intentions. You may sit down to work on a project you genuinely care about, but find yourself repeatedly checking your phone—not because the project isn’t meaningful, but because your brain’s reward circuitry has been hijacked by the promise of novel stimulation.

## Cognitive Switching Costs: The Tax of Fragmented Attention

Every time you switch your attention from one task to another, you pay a cognitive tax. This “switching cost” manifests in several ways:

### 1\. Attentional Reorientation

When you switch tasks, your brain must disengage from the current neural networks activated by Task A and activate those required for Task B. This neural reconfiguration consumes energy and time—creating what feel like “mental gear shifts” throughout your day.

Dr. Sophie Leroy, an organizational behavior researcher, found that when people switch tasks, their attention doesn’t immediately follow. In her studies, participants who were interrupted during a task continued to think about the unfinished work even while trying to focus on the new task. This “attention residue” impaired performance on the subsequent task.

### 2\. Rule Activation/Inhibition

Different tasks require different cognitive rules. Writing an email activates language production systems, while analyzing a spreadsheet activates numerical processing systems. When switching between tasks, your brain must load the appropriate rule set while suppressing the previous one.

This activation/inhibition cycle is metabolically expensive, drawing on limited glucose resources in the brain. Like a muscle, this cognitive function fatigues with repeated use, making each subsequent task switch more difficult and less efficient.

### 3\. Working Memory Reloading

As discussed earlier, task switching requires reloading relevant information into working memory. The more complex the tasks, the more severe this cost becomes.

Computer programmers understand this intuitively—many report that interruptions during complex coding work can set them back 30-60 minutes, as they struggle to reconstruct their mental model of the code they were working on.

### 4\. Error Rate Increase

Perhaps most concerning is the dramatic increase in errors that accompanies frequent task switching. Research from Michigan State University found that interruptions as brief as 2.8 seconds doubled error rates in a sequence-based task, while interruptions of 4.4 seconds tripled them.

The cumulative impact of these switching costs helps explain why a day filled with interruptions can leave you feeling exhausted yet unproductive. Your brain has been working intensely—not on your primary work, but on the demanding process of repeatedly reorienting itself.

## The Myth of Autopilot: When Attention Systems Compete

We often assume we can put routine tasks on “autopilot” while focusing on something else. While driving a familiar route, for instance, you might find yourself deep in thought or conversation, seemingly managing both tasks simultaneously.

Neuroscience reveals a more complex reality. Your brain has two distinct processing modes:

### 1\. Controlled Processing

Controlled processing is conscious, deliberate thinking that requires your executive control network. This includes activities like solving problems, learning new information, or making decisions. This type of processing:

*   Requires conscious awareness
*   Consumes significant mental energy
*   Has limited capacity
*   Is relatively slow and sequential

### 2\. Automatic Processing

Automatic processing handles well-learned routines and skills that have become habitual. This includes activities like typing if you’re an experienced typist, driving a familiar route, or following your morning routine. This type of processing:

*   Operates largely outside conscious awareness
*   Requires minimal mental energy
*   Can run in parallel with other automatic processes
*   Is fast and efficient

The problem arises when we try to multitask by combining controlled and automatic processing. When you try to compose an email while on a conference call, both tasks involve controlled processing, creating direct competition for your limited cognitive resources.

Even when one task is automatic (like driving a familiar route), problems can arise when unexpected situations demand that automatic processes shift back to controlled mode—like when a child runs into the street while you’re deep in conversation.

This explains why “highway hypnosis” occurs—your brain’s automatic processing handles the driving while your conscious mind wanders. It works until something unexpected happens, at which point your reaction time may be dangerously delayed.

The modern workplace often ignores this neurological reality, expecting people to handle multiple streams of controlled processing simultaneously—following a presentation while checking email, participating in a meeting while completing unrelated work, or maintaining a conversation while responding to messages.

## Technology and the Attentional Dark Pattern

The challenges facing your attention system aren’t accidental—they’re by design. Many digital technologies employ what user experience designers call “dark patterns”—design features that manipulate users into behaviors that benefit the platform rather than the user.

From an attentional perspective, these dark patterns target specific vulnerabilities in your brain’s architecture:

### Exploiting the Attentional Bottleneck

Your orienting network can only direct attention to one cognitively demanding task at a time. Notification systems exploit this bottleneck by forcing attentional shifts, knowing that your brain will automatically orient to novel stimuli regardless of your conscious intentions.

Ever notice how a notification can interrupt your train of thought even if you don’t check it? That’s your orienting system being hijacked, with or without your consent.

### Weaponizing Intermittent Reinforcement

Your brain’s reward systems respond most powerfully to unpredictable rewards. Social media platforms leverage this by delivering unpredictable social validation (likes, comments, shares) on variable schedules—the same mechanism that makes gambling addictive.

This creates what behavioral economists call a “ludic loop”—a cycle of anticipation, action, and reward that can be difficult to exit voluntarily. Each check of your phone or refresh of your feed is another pull of the slot machine lever.

### Exploiting Completion Bias

Your brain experiences satisfaction when completing tasks, with each completion triggering a small dopamine reward. Notification systems exploit this by creating artificial “incomplete” states—unread messages, unseen posts—that trigger a completionist urge.

Ever felt compelled to clear notification badges even when you know the content is unimportant? That’s completion bias at work.

### Leveraging Social Validation

As social creatures, our brains assign high priority to information about our social standing. Digital platforms exploit this by quantifying social validation through metrics like followers, likes, and engagement rates.

“The social feedback mechanisms in these platforms aren’t neutral,” explains social psychologist Dr. Sherry Turkle. “They’re designed to create dependency by tying self-worth to visible metrics of social approval.”

### Eliminating Natural Stopping Cues

In natural environments, activities have inherent stopping points. A conversation ends, a meal is finished, a book concludes. Digital platforms deliberately remove these natural boundaries through techniques like infinite scrolling, autoplay, and algorithmic content suggestions.

This exploits what behavioral scientists discovered in eating behavior—when there’s no obvious endpoint, we consume more. The removal of stopping cues bypasses your executive control network’s ability to make conscious decisions about when to disengage.

## The Neurological Impact of Chronic Distraction

What happens to your brain under conditions of persistent distraction? Emerging research suggests concerning changes at the neural level:

### Altered Default Mode Network

Your brain has a network called the default mode network (DMN) that activates when you’re not focused on external tasks—during mindwandering, self-reflection, and creative thought. This network plays crucial roles in memory consolidation, identity formation, and insight generation.

Research from the University of Southern California shows that chronic media multitasking is associated with reduced gray matter in regions associated with the DMN. This raises concerns about long-term impacts on creative thinking, self-awareness, and memory formation.

### Reward System Recalibration

Constant exposure to high-stimulation digital environments may recalibrate your dopamine system, potentially making normal levels of stimulation feel boring or understimulating.

Dr. Victoria Dunckley, who studies technology’s effects on brain development, explains: “When the brain becomes accustomed to high levels of stimulation, activities with normal stimulation levels—like reading a book or having a face-to-face conversation—may feel tedious by comparison.”

This may help explain why many people report increasing difficulty engaging with slower-paced activities that historically provided great satisfaction—deep reading, conversation, nature observation—after periods of intensive digital engagement.

### Diminished Cognitive Control

Perhaps most concerning is evidence suggesting that chronic distraction may weaken the neural networks involved in sustained attention and cognitive control.

A longitudinal study from Stanford University found that high media multitasking was associated with reduced performance on tasks requiring attentional filtering—the ability to ignore irrelevant stimulation. Troublingly, these effects persisted even when participants were instructed to focus on a single task, suggesting changes to baseline attentional capacity.

These findings suggest a troubling possibility: that our distracted behaviors aren’t merely habits we can change at will, but may involve actual neural restructuring that makes sustained attention increasingly difficult.

## The Attentional Reserve: Your Brain’s Limited Fuel

Your capacity for focused attention isn’t infinite—it depends on a limited resource pool that neuroscientists are still working to fully understand. Current research suggests several key components of this “attentional reserve”:

### Glucose Availability

Your brain is an energy-intensive organ, consuming approximately 20% of your body’s energy despite comprising only 2% of your body weight. Complex cognitive tasks—particularly those involving the executive control network—demand even higher energy expenditure.

The primary fuel for these functions is glucose. When you engage in focused mental work, you’re literally burning through this limited resource. Studies show that tasks requiring self-control (a function of the executive control network) can temporarily deplete blood glucose levels, potentially explaining why willpower seems to diminish throughout a demanding day.

### Sleep Quality

Sleep isn’t merely rest for your brain—it’s an active process essential for attentional capacity. During deep sleep, your brain clears metabolic waste products that accumulate during waking hours, including adenosine—a compound that inhibits alertness.

Research from UC Berkeley demonstrates that even one night of disrupted sleep impairs the functional connectivity between the amygdala and prefrontal cortex, reducing emotional regulation capacity and executive function—key components of attentional control.

The relationship between sleep and attention creates a troubling cycle: poor attention management (like late-night screen use) disrupts sleep quality, which further degrades attentional capacity the following day.

### Stress Regulation

Your ability to direct and sustain attention is intimately connected to your stress levels. Chronic stress triggers prolonged cortisol release, which has been shown to reduce activity in the prefrontal cortex while increasing activation in the amygdala—essentially strengthening your reactivity while weakening your executive control.

“Under conditions of high stress, the brain shifts from thoughtful ‘top-down’ control by the prefrontal cortex to reactive ‘bottom-up’ control by the amygdala,” explains neuroscientist Dr. Amy Arnsten. “It’s an adaptive response for acute physical threats but maladaptive for modern cognitive work.”

This helps explain why it becomes increasingly difficult to maintain focused attention during periods of high stress—your neurophysiology has literally shifted away from the brain regions that support controlled attention.

## Neurodiversity: Different Brains, Different Challenges

It’s important to recognize that brains vary significantly in their attentional architecture. Neurodevelopmental conditions like ADHD, autism spectrum disorders, and sensory processing differences create unique attentional landscapes.

### The ADHD Brain

Attention-Deficit/Hyperactivity Disorder (ADHD) involves variations in dopamine signaling and executive function networks that create distinct attentional patterns:

*   Greater difficulty sustaining attention on low-stimulation tasks
*   Enhanced capacity for hyperfocus under specific conditions
*   More vulnerability to distraction
*   Different reward sensitivity

For people with ADHD, standard advice about focus and distraction management can be ineffective or even counterproductive. As ADHD researcher Dr. Russell Barkley explains, “ADHD isn’t a disorder of not knowing what to do, but of not being able to do what you know.”

This highlights an important principle that applies to all brains: effective attention management must be tailored to your actual neural wiring, not an idealized standard.

### Highly Sensitive Processing

Approximately 15-20% of the population has what psychologist Dr. Elaine Aron identifies as Sensory Processing Sensitivity—a trait characterized by deeper processing of sensory information and greater reactivity to both positive and negative stimuli.

People with this trait may experience environments as more stimulating than others do, reaching cognitive and sensory overload more quickly in noisy or complex environments. Their attentional systems may require more frequent recovery periods and more carefully managed sensory input.

### The Autism Spectrum

Individuals on the autism spectrum often experience significant differences in attention allocation, including:

*   Enhanced attention to detail
*   Different patterns of sensory filtering
*   Challenges with attention shifting
*   Distinct patterns of interest maintenance

These neurological variations underscore an essential truth: there is no single “correct” way for attention to operate. Effective attention management isn’t about forcing all brains to function identically, but about understanding your unique attentional profile and creating conditions that work with rather than against your neurological wiring.

## Reflection: Mapping Your Attentional Landscape

Understanding the science of attention is valuable only if you can apply it to your specific situation. Consider these questions to map your personal attentional terrain:

1.  **Recovery Signals**: What physical or mental sensations tell you your attentional systems need a break? (Mental fogginess? Irritability? Increased distractibility?)
2.  **Optimal Stimulation**: In what environments does your focus naturally deepen? (Complete silence? Ambient background noise? Morning or evening?)
3.  **Drain Identification**: Which activities most rapidly deplete your attentional reserves? (Video calls? Open office environments? Specific types of cognitive work?)
4.  **Attention Triggers**: What specific stimuli most easily capture and redirect your attention? (Message notifications? Certain sounds? Visual movement?)
5.  **Restoration Practices**: What activities most effectively restore your capacity for sustained attention? (Nature exposure? Physical exercise? Brief meditation?)

Taking time to answer these questions creates a personalized attentional profile that will prove valuable as we explore practical strategies in later chapters.

## The Path Forward: Working With Your Brain, Not Against It

The neuroscience we’ve explored reveals both the limitations of human attention and the sophisticated systems designed to exploit those limitations. This might seem discouraging—how can we possibly win against both our own neurological constraints and the systems engineered to hijack them?

The answer lies not in fighting your brain’s fundamental nature but in aligning your environment and habits with your neurological reality.

In the coming chapters, we’ll explore practical strategies that work with your brain’s attentional systems rather than against them. These approaches recognize that sustainable attention management isn’t about heroic feats of willpower, but about creating conditions where your natural attentional capacities can thrive.

The goal isn’t to transform your brain into something it’s not, but to create environments and practices that support its inherent capabilities while mitigating its vulnerabilities. With this science-informed foundation, you’re now prepared to develop a truly effective approach to vanquishing the noise.

**Chapter Summary:**

*   Attention is managed by three neural networks: the alerting network, orienting network, and executive control network
*   Working memory has strict capacity limits that make multitasking largely an illusion
*   Your brain has a novelty bias mediated by dopamine that makes constant digital stimulation compelling
*   Task switching incurs significant cognitive costs that accumulate throughout the day
*   Digital technologies deliberately exploit vulnerabilities in your attentional systems
*   Chronic distraction may cause concerning changes to brain structure and function
*   Your capacity for focused attention depends on physiological factors including glucose, sleep, and stress
*   Brains vary significantly in their attentional architecture, requiring personalized management strategies
*   Effective attention management works with your brain’s nature rather than fighting against it

