# Part I: Understanding the Noise

[PLACEHOLDER: Image]

